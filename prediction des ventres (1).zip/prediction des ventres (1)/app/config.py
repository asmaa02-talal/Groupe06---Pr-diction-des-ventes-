# config.py
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",       # met ton mot de passe root si tu en as un
    "database": "akforecast_db",
    "port": 3306
}

# Dossiers
UPLOAD_DIR = "uploads"
RESULTS_DIR = "results"

# Crée dossiers si n'existent pas
import os
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)
