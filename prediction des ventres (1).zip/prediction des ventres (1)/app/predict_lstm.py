# ============================================================
#  Sales Forecasting 
# ============================================================

import os
import logging
import warnings
import numpy as np
import pandas as pd
import time

import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt

from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.ensemble import RandomForestRegressor

# --- Config Logs ---
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
logging.getLogger('tensorflow').setLevel(logging.ERROR)
warnings.filterwarnings("ignore")

# --- Import TensorFlow Sécurisé ---
try:
    from tensorflow.keras.models import Sequential # type: ignore
    from tensorflow.keras.layers import LSTM, Dense, Input # type: ignore
    TENSORFLOW_AVAILABLE = True
except ImportError:
    TENSORFLOW_AVAILABLE = False


# ============================================================
# UTILS
# ============================================================

def create_lag_features(series, n_lags=7):
    X, y = [], []
    if len(series) <= n_lags:
        return np.array([]), np.array([])
    for i in range(len(series) - n_lags):
        X.append(series[i:i + n_lags])
        y.append(series[i + n_lags])
    return np.array(X), np.array(y)

def build_lstm_model(input_shape):
    if not TENSORFLOW_AVAILABLE: return None
    model = Sequential([
        Input(shape=input_shape),
        LSTM(50, activation="tanh"),
        Dense(1)
    ])
    model.compile(optimizer="adam", loss="mse")
    return model

def plot_results(dates, real, future_dates, future_preds, path, model_name):
    """ Génère le graphique sans bloquer l'application """
    try:
        # Création explicite de la figure
        fig = plt.figure(figsize=(10, 5))
        
        # Courbes
        plt.plot(dates, real, label="Historique", color="#94a3b8", linewidth=2)
        plt.plot(future_dates, future_preds, label=f"Prévision {model_name}", color="#2563eb", linewidth=2.5)
        
        # Esthétique
        plt.title(f"Prévision des ventes : {model_name}", fontsize=12, fontweight='bold', color="#1e293b")
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.5)
        plt.tight_layout()
        
        # Sauvegarde et fermeture immédiate pour libérer la mémoire
        plt.savefig(path, dpi=100)
        plt.close(fig) 
        print(f"✅ Graphique généré : {path}")
    except Exception as e:
        print(f"❌ Erreur graphique : {e}")

# ============================================================
# PIPELINE
# ============================================================

def run_forecast_pipeline(csv_path, future_days=30, output_dir="results"):
    print("--- DÉBUT ANALYSE ---")
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. Lecture Robuste
    try:
        df = pd.read_csv(csv_path)
        if len(df.columns) < 2: df = pd.read_csv(csv_path, sep=';')
    except:
        raise ValueError("Erreur de lecture CSV.")
        
    df.columns = df.columns.str.strip().str.lower()
    
    # Gestion des dates
    raw_dates = df["date"].astype(str)
    df["date"] = pd.to_datetime(raw_dates, dayfirst=True, errors='coerce')
    df = df.dropna(subset=["date"]).sort_values("date")
    
    # Duplication si fichier trop petit (évite le crash sur petit dataset)
    if len(df) < 15:
        print("⚠️ Fichier trop petit, duplication des données...")
        df = pd.concat([df]*3, ignore_index=True)
    
    # Conversion numérique
    values = df["ventes"].astype(str).str.replace(',', '.').astype(float).values.reshape(-1, 1)
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(values)
    
    # 2. Préparation
    window = 7
    X, y = create_lag_features(scaled.flatten(), window)
    
    if len(X) < 2:
        # Fallback de sécurité
        print("❌ Données insuffisantes après traitement.")
        return {"metrics": {}, "plots": {}, "forecasts": {}, "history_df": df}

    split = int(0.8 * len(X))
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]
    
    future_dates = pd.date_range(df["date"].iloc[-1] + pd.Timedelta(days=1), periods=future_days)
    
    metrics = {}
    plots = {}
    forecasts = {}

    # 3. Random Forest (Modèle Rapide)
    try:
        print("🚀 Lancement Random Forest...")
        rf = RandomForestRegressor(n_estimators=100, random_state=42)
        rf.fit(X_train, y_train)
        
        # Prévision
        last_seq = scaled[-window:].flatten()
        future_scaled = []
        for _ in range(future_days):
            pred = rf.predict(last_seq.reshape(1, -1))[0]
            future_scaled.append(pred)
            last_seq = np.append(last_seq[1:], pred)
            
        future_rf = scaler.inverse_transform(np.array(future_scaled).reshape(-1, 1)).flatten()
        
        # Calcul RMSE (si possible)
        rmse = 0.0
        if len(X_test) > 0:
            rmse = np.sqrt(mean_squared_error(y_test, rf.predict(X_test)))
            
        rf_path = os.path.join(output_dir, "forecast_rf.png")
        plot_results(df["date"], df["ventes"], future_dates, future_rf, rf_path, "Random Forest")
        
        metrics["Random Forest"] = {"MAE": 0.0, "RMSE": rmse}
        plots["Random Forest"] = rf_path
        forecasts["Random Forest"] = future_rf
        
    except Exception as e:
        print(f"Erreur RF: {e}")

    # 4. LSTM (Modèle Deep Learning)
    if TENSORFLOW_AVAILABLE:
        try:
            print("🚀 Lancement LSTM...")
            X_train_r = X_train.reshape(-1, window, 1)
            model = build_lstm_model((window, 1))
            
            # Entraînement rapide
            model.fit(X_train_r, y_train, epochs=15, batch_size=1, verbose=0)
            
            # Prévision
            last_seq = scaled[-window:].flatten()
            future_scaled_lstm = []
            for _ in range(future_days):
                pred = model.predict(last_seq.reshape(1, window, 1), verbose=0)[0, 0] # type: ignore
                future_scaled_lstm.append(pred)
                last_seq = np.append(last_seq[1:], pred)
                
            future_lstm = scaler.inverse_transform(np.array(future_scaled_lstm).reshape(-1, 1)).flatten()
            
            lstm_path = os.path.join(output_dir, "forecast_lstm.png")
            plot_results(df["date"], df["ventes"], future_dates, future_lstm, lstm_path, "LSTM")
            
            metrics["LSTM"] = {"MAE": 0.0, "RMSE": rmse}
            plots["LSTM"] = lstm_path
            forecasts["LSTM"] = future_lstm
            
        except Exception as e:
            print(f"Erreur LSTM: {e}")

    print("--- FIN ANALYSE ---")
    return {
        "metrics": metrics,
        "plots": plots,
        "forecasts": forecasts,
        "history_df": df
    }