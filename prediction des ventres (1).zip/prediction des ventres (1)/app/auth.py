import bcrypt
# Assurez-vous que votre database.py a bien insert_user
# Si insert_user n'accepte pas 'company', le code ci-dessous gère l'appel correctement
from database import insert_user, get_user_by_email

# ---------------------------------------
# Hash du mot de passe
# ---------------------------------------
def hash_password(password: str) -> bytes:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())

# ---------------------------------------
# Vérification du mot de passe
# ---------------------------------------
def verify_password(password: str, hashed_password) -> bool:
    if isinstance(hashed_password, str):
        hashed_password = hashed_password.encode("utf-8")
    return bcrypt.checkpw(password.encode("utf-8"), hashed_password)

# ---------------------------------------
# Inscription (Modifiée pour accepter Company)
# ---------------------------------------
def register_user(name, email, password, company=None):
    if get_user_by_email(email):
        return False, "Cet email est déjà utilisé."

    pw_hash = hash_password(password)

    # NOTE : Si votre fonction insert_user dans database.py n'a pas 
    # d'argument 'company', nous l'appelons sans.
    # Si vous avez modifié database.py pour stocker company, ajoutez-le ici.
    try:
        # Tente d'insérer avec company (si BDD à jour)
        # uid = insert_user(name, email, pw_hash, company) 
        
        # Pour l'instant, on reste compatible avec votre database.py actuel :
        uid = insert_user(name, email, pw_hash)
        
        if uid:
            return True, "Compte créé avec succès"
    except Exception as e:
        return False, f"Erreur technique : {str(e)}"
        
    return False, "Erreur lors de la création du compte"

# ---------------------------------------
# Login
# ---------------------------------------
def verify_credentials(email, password):
    user = get_user_by_email(email)
    if not user:
        return False, None

    if verify_password(password, user["password"]):
        return True, {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            # On ajoute une valeur par défaut pour company si absente
            "company": user.get("company", "Mon Entreprise") 
        }

    return False, None