import mysql.connector
from app.config import DB_CONFIG

def update_database_schema():
    print("🔌 Connexion à la base de données...")
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        # Liste des colonnes à ajouter si elles manquent
        columns_to_add = [
            ("mae_score", "FLOAT"),
            ("best_model", "VARCHAR(100)"),
            ("horizon_days", "INT"),
            ("pdf_path", "VARCHAR(255)")
        ]
        
        print("🛠️  Vérification et mise à jour de la table 'predictions'...")
        
        for col_name, col_type in columns_to_add:
            try:
                # Tente d'ajouter la colonne. Si elle existe déjà, MySQL renverra une erreur qu'on ignore.
                cursor.execute(f"ALTER TABLE predictions ADD COLUMN {col_name} {col_type}")
                print(f"✅ Colonne ajoutée : {col_name}")
            except mysql.connector.Error as err:
                if err.errno == 1060: # Code erreur pour "Duplicate column name"
                    print(f"ℹ️  La colonne '{col_name}' existe déjà.")
                else:
                    print(f"❌ Erreur sur '{col_name}': {err}")

        conn.commit()
        cursor.close()
        conn.close()
        print("\n🚀 Base de données mise à jour avec succès !")
        
    except mysql.connector.Error as err:
        print(f"❌ Erreur de connexion : {err}")

if __name__ == "__main__":
    update_database_schema()