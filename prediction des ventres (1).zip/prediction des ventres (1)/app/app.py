import streamlit as st
import pandas as pd
import plotly.express as px
import os
import datetime

# Import des modules locaux
from styles import load_css
from auth import register_user, verify_credentials
from database import insert_sales_bulk, get_sales_for_user, get_predictions_for_user, save_prediction_report
from predict_lstm import run_forecast_pipeline
from report_generator import generate_pdf_report
from config import UPLOAD_DIR, RESULTS_DIR

# --- CONFIG PAGE ---
st.set_page_config(
    page_title="AK_Forecast",
    layout="wide",
    page_icon="📈",
    initial_sidebar_state="expanded"
)

# Chargement du Design (CSS)
load_css()

# Initialisation Session
if "user" not in st.session_state:
    st.session_state.user = None

# =========================================================
# 🔐 LOGIN SCREEN (DESIGN SAAS / SPLIT SCREEN)
# =========================================================
def login_screen():
    # Espace pour aérer le haut de page
    st.write("")
    st.write("")

    # Layout : Texte Marketing à Gauche (1.5) | Formulaire à Droite (1)
    col_text, col_form = st.columns([1.5, 1], gap="large")

    # --- COLONNE GAUCHE (PITCH MARKETING) ---
    with col_text:
        st.markdown("""
        <div style='margin-top: 20px;'>
            <h1 style='font-size: 3.5rem; line-height: 1.1; margin-bottom: 20px;'>
                Anticipez vos ventes<br>avec l'Intelligence Artificielle.
            </h1>
            <h3 style='color: #475569; font-weight: 400; font-size: 1.2rem; line-height: 1.6;'>
                AK_Forecast transforme vos données historiques en
                <span style='color: #2563eb; font-weight: 700;'>décisions stratégiques</span>.
                Optimisez vos stocks et maximisez votre chiffre d'affaires grâce à nos modèles prédictifs avancés.
            </h3>
            <br>
            <div style="display: flex; gap: 20px; margin-top: 20px;">
                <div style="background: #eff6ff; padding: 15px; border-radius: 12px; border: 1px solid #dbeafe; width: 100%;">
                    <span style="font-size: 1.5rem;">🚀</span><br><b>Modèles IA</b><br><span style="font-size:0.9rem; color:#64748b;">LSTM & Random Forest</span>
                </div>
                <div style="background: #eff6ff; padding: 15px; border-radius: 12px; border: 1px solid #dbeafe; width: 100%;">
                    <span style="font-size: 1.5rem;">📊</span><br><b>Analytics</b><br><span style="font-size:0.9rem; color:#64748b;">Tableaux interactifs</span>
                </div>
                <div style="background: #eff6ff; padding: 15px; border-radius: 12px; border: 1px solid #dbeafe; width: 100%;">
                    <span style="font-size: 1.5rem;">📑</span><br><b>Reporting</b><br><span style="font-size:0.9rem; color:#64748b;">Export PDF Automatisé</span>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # --- COLONNE DROITE (FORMULAIRE DANS UNE CARTE) ---
    with col_form:
        # Le CSS "login-container" s'applique automatiquement via styles.py si présent, 
        # sinon on utilise st.container avec le style par défaut.
        with st.container():
            st.markdown("### Accéder à votre espace")
            tab_login, tab_register = st.tabs(["Se connecter", "Créer un compte"])

            # --- ONGLET CONNEXION ---
            with tab_login:
                st.write("")
                email = st.text_input("Email professionnel", key="login_email", placeholder="ex: admin@akforecast.com")
                password = st.text_input("Mot de passe", type="password", key="login_pass")

                st.write("")
                if st.button("Connexion Sécurisée", key="btn_login", use_container_width=True):
                    if email and password:
                        with st.spinner("Vérification des accès..."):
                            ok, user = verify_credentials(email, password)
                            if ok:
                                st.session_state.user = user
                                st.rerun()
                            else:
                                st.error("Email ou mot de passe incorrect.")
                    else:
                        st.warning("Veuillez remplir tous les champs.")

            # --- ONGLET INSCRIPTION ---
            with tab_register:
                st.write("")
                c1, c2 = st.columns(2)
                with c1:
                    new_name = st.text_input("Nom complet", placeholder="Jean Dupont")
                with c2:
                    new_company = st.text_input("Entreprise", placeholder="Ma Société")

                new_email = st.text_input("Email", key="reg_email")
                new_pwd = st.text_input("Mot de passe", type="password", key="reg_pass")

                st.write("")
                if st.button("Commencer l'essai gratuit", key="btn_register", use_container_width=True):
                    if new_email and new_pwd and new_name:
                        ok, msg = register_user(new_name, new_email, new_pwd, new_company)
                        if ok:
                            st.success("Compte créé avec succès ! Connectez-vous.")
                            st.balloons()
                        else:
                            st.error(msg)
                    else:
                        st.warning("Tous les champs sont obligatoires.")

# Si l'utilisateur n'est pas connecté, afficher le Login Screen
if not st.session_state.user:
    login_screen()
    st.stop()


# =========================================================
# 📱 APPLICATION PRINCIPALE (DASHBOARD)
# =========================================================

# --- SIDEBAR ---
with st.sidebar:
    st.title("AK_Forecast")
    st.markdown(f"Bonjour, **{st.session_state.user['name']}**")
    st.caption(f"🏢 {st.session_state.user.get('company', 'Entreprise')}")
    st.markdown("---")

    menu = st.radio(
        "Navigation",
        ["📊 Dashboard", "🤖 Prédiction AI", "📑 Mes Rapports"],
        index=0
    )

    st.markdown("---")
    if st.button("Déconnexion", use_container_width=True):
        st.session_state.user = None
        st.rerun()

# --- 1. DASHBOARD ---
if menu == "📊 Dashboard":
    st.title("Tableau de Bord")
    st.markdown("Vue d'ensemble de vos données commerciales.")

    df_sales = get_sales_for_user(st.session_state.user['id'])

    if df_sales.empty:
        st.info("👋 Bienvenue ! Aucune donnée disponible. Allez dans l'onglet **Prédiction AI** pour importer vos premières ventes.")
    else:
        # KPI Cards (Design Pro)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Chiffre d'affaires", f"{df_sales['ventes'].sum():,.0f} €", delta="Global")
        c2.metric("Vente Max", f"{df_sales['ventes'].max():,.0f} €")
        c3.metric("Vente Min", f"{df_sales['ventes'].min():,.0f} €")
        c4.metric("Données jusqu'au", f"{pd.to_datetime(df_sales.iloc[-1]['date']).strftime('%d/%m/%Y')}")

        st.markdown("---")

        # Graphique Plotly (Light Theme)
        st.subheader("📈 Évolution Temporelle des Ventes")
        fig = px.area(
            df_sales,
            x='date',
            y='ventes',
            template="plotly_white", # Thème clair
        )
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font_color="#1e293b",
            xaxis_title="Date",
            yaxis_title="Volume des Ventes",
            margin=dict(l=0, r=0, t=10, b=0),
            height=400
        )
        # Courbe bleue avec remplissage léger
        fig.update_traces(line_color='#2563eb', fillcolor="rgba(37, 99, 235, 0.1)")
        st.plotly_chart(fig, use_container_width=True)

# --- 2. PRÉDICTION ---
elif menu == "🤖 Prédiction AI":
    st.title("Générateur de Prévisions")
    st.markdown("Importez vos données historiques pour générer des prévisions basées sur l'IA.")

    # Layout en colonnes pour les inputs
    c_input, c_info = st.columns([1, 1])

    with c_input:
        uploaded_file = st.file_uploader("📂 Fichier CSV (colonnes: date, ventes)", type="csv")
        horizon = st.slider("📅 Horizon de prévision (Jours)", 30, 365, 90)

    if st.button("🚀 Lancer l'analyse AI", type="primary"):
        if uploaded_file:
            with st.spinner("🧠 L'IA analyse vos données... Entraînement des modèles en cours..."):
                # Sauvegarde temporaire
                filepath = os.path.join(UPLOAD_DIR, uploaded_file.name)
                with open(filepath, "wb") as f:
                    f.write(uploaded_file.getbuffer())

                # Exécution du Pipeline
                res = run_forecast_pipeline(filepath, future_days=horizon, output_dir=RESULTS_DIR)

                # Sauvegarde BDD (Historique)
                insert_sales_bulk(st.session_state.user['id'], res['history_df'])

                # Identification du meilleur modèle
                best_model_name = min(res["metrics"], key=lambda k: res["metrics"][k]["RMSE"])
                best_metrics = res["metrics"][best_model_name]

                # Génération PDF
                pdf_filename = f"Rapport_{st.session_state.user['id']}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                pdf_full_path = os.path.join(RESULTS_DIR, pdf_filename)

                generate_pdf_report(
                    st.session_state.user,
                    res['history_df'],
                    res['forecasts'],
                    res['metrics'],
                    res['plots'],
                    best_model_name,
                    pdf_full_path
                )

                # Sauvegarde Rapport BDD
                save_prediction_report(
                    st.session_state.user['id'],
                    pdf_full_path,
                    best_model_name,
                    horizon,
                    best_metrics['MAE']
                )

                st.success("✅ Analyse terminée avec succès !")

                # --- AFFICHAGE RÉSULTATS ---
                st.markdown("---")
                res_col1, res_col2 = st.columns([2, 1])

                with res_col1:
                    st.subheader(f"Prévision : {best_model_name}")
                    st.image(res["plots"][best_model_name], use_container_width=True)

                with res_col2:
                    st.subheader("Performance")
                    st.metric("Modèle Recommandé", best_model_name)
                    st.metric("Marge d'erreur (MAE)", f"{best_metrics['MAE']:.2f}")
                    st.caption("Plus le MAE est bas, plus la prévision est précise.")

                    st.markdown("### Export")
                    with open(pdf_full_path, "rb") as f:
                        st.download_button(
                            label="📥 Télécharger le Rapport PDF",
                            data=f,
                            file_name=pdf_filename,
                            mime="application/pdf",
                            use_container_width=True
                        )
        else:
            st.error("Veuillez charger un fichier CSV pour commencer.")

# --- 3. RAPPORTS ---
elif menu == "📑 Mes Rapports":
    st.title("Historique des Analyses")

    reports = get_predictions_for_user(st.session_state.user['id'])

    if not reports:
        st.info("Aucun rapport généré pour le moment.")
    else:
        for r in reports:
            # Sécurisation de la date
            date_str = r['created_at'].strftime('%d %B %Y à %H:%M') if hasattr(r['created_at'], 'strftime') else str(r['created_at'])
            
            # Sécurisation du modèle (si vide, on met "Inconnu")
            model_name = r.get('best_model') or "Inconnu"

            with st.expander(f"📄 Rapport du {date_str} — Modèle {model_name}"):
                c_a, c_b, c_c = st.columns([1, 1, 1])
                
                # Gestion des valeurs vides (None) pour Horizon et MAE
                horizon = r.get('horizon_days')
                mae = r.get('mae_score')

                # Affichage conditionnel pour éviter le crash
                if horizon:
                    c_a.markdown(f"**Horizon :** {horizon} jours")
                else:
                    c_a.markdown("**Horizon :** N/A")

                if mae is not None:
                    c_b.markdown(f"**Précision (MAE) :** {mae:.2f}")
                else:
                    c_b.markdown("**Précision (MAE) :** N/A")

                # Téléchargement PDF
                if r.get('pdf_path') and os.path.exists(r['pdf_path']):
                    with open(r['pdf_path'], "rb") as pdf_file:
                        c_c.download_button(
                            label="📥 Télécharger le PDF",
                            data=pdf_file,
                            file_name=os.path.basename(r['pdf_path']),
                            mime="application/pdf"
                        )
                else:
                    c_c.error("Fichier expiré ou introuvable.")