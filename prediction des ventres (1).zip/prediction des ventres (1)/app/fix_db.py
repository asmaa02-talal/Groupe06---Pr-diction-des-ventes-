import mysql.connector
from config import DB_CONFIG

def fix_database():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        print("🔧 Réparation de la base de données...")
        
        # Ajout des colonnes manquantes
        try:
            cursor.execute("ALTER TABLE predictions ADD COLUMN best_model VARCHAR(50)")
            print("✅ Colonne 'best_model' ajoutée.")
        except mysql.connector.Error as err:
            print(f"Info: {err}")

        try:
            cursor.execute("ALTER TABLE predictions ADD COLUMN horizon_days INT")
            print("✅ Colonne 'horizon_days' ajoutée.")
        except mysql.connector.Error as err:
            print(f"Info: {err}")

        try:
            cursor.execute("ALTER TABLE predictions ADD COLUMN mae_score FLOAT")
            print("✅ Colonne 'mae_score' ajoutée.")
        except mysql.connector.Error as err:
            print(f"Info: {err}")

        conn.commit()
        cursor.close()
        conn.close()
        print("🚀 Base de données mise à jour avec succès !")
        
    except Exception as e:
        print(f"Erreur : {e}")

if __name__ == "__main__":
    fix_database()