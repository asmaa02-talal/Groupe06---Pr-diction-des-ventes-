import mysql.connector
from config import DB_CONFIG
import pandas as pd
from datetime import datetime

def get_conn():
    return mysql.connector.connect(**DB_CONFIG)

# ---------------- USERS ----------------
def insert_user(name, email, password):
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO users (name, email, password) VALUES (%s,%s,%s)",
            (name, email, password)
        )
        conn.commit()
        uid = cur.lastrowid
        return uid
    except mysql.connector.Error:
        return None
    finally:
        cur.close()
        conn.close()

def get_user_by_email(email):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cur.fetchone()
    cur.close()
    conn.close()
    return user

# ---------------- SALES ----------------
def get_sales_for_user(user_id):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT date, ventes
        FROM sales
        WHERE user_id=%s
        ORDER BY date ASC
    """, (user_id,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return pd.DataFrame(rows)

def insert_sales_bulk(user_id, df: pd.DataFrame, dataset_name="dataset"):
    conn = get_conn()
    cursor = conn.cursor()
    
    # On nettoie d'abord les anciennes données de ce dataset pour éviter les doublons lors des tests
    # (Optionnel : tu peux retirer ce delete si tu veux accumuler)
    cursor.execute("DELETE FROM sales WHERE user_id=%s", (user_id,)) 
    
    sql = """
        INSERT INTO sales (user_id, date, ventes, dataset_name)
        VALUES (%s, %s, %s, %s)
    """
    records = []
    for _, row in df.iterrows():
        records.append((
            user_id,
            pd.to_datetime(row["date"]).date(),
            float(row["ventes"]),
            dataset_name
        ))
    
    cursor.executemany(sql, records)
    conn.commit()
    cursor.close()
    conn.close()
    return len(records)

# ---------------- REPORTS / PREDICTIONS ----------------
def save_prediction_report(user_id, pdf_path, best_model, horizon, mae):
    """ Enregistre le chemin du rapport dans la BDD """
    conn = get_conn()
    cursor = conn.cursor()
    sql = """
        INSERT INTO predictions (user_id, pdf_path, best_model, horizon_days, mae_score, created_at)
        VALUES (%s, %s, %s, %s, %s, NOW())
    """
    cursor.execute(sql, (user_id, pdf_path, best_model, horizon, mae))
    conn.commit()
    cursor.close()
    conn.close()

def get_predictions_for_user(user_id):
    conn = get_conn()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT id, created_at, pdf_path, best_model, horizon_days, mae_score
        FROM predictions
        WHERE user_id = %s
        ORDER BY created_at DESC
    """, (user_id,))
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return rows