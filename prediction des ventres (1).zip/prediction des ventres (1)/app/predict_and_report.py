import matplotlib.pyplot as plt
from fpdf import FPDF
import os
from datetime import datetime

def generate_pdf_report(df, predictions, user_name):
    os.makedirs("rapports", exist_ok=True)

    # --------- GRAPH ----------
    plt.figure(figsize=(8,4))
    plt.plot(df["date"], df["ventes"], label="Historique")
    plt.plot(
        range(len(df), len(df)+len(predictions)),
        predictions,
        label="Prévision",
        linestyle="--"
    )
    plt.legend()
    plt.title("Prévision des ventes")
    img_path = "results/graph.png"
    plt.savefig(img_path)
    plt.close()

    # --------- PDF ----------
    pdf = FPDF()
    pdf.add_page()

    # PAGE DE GARDE
    pdf.set_font("Arial","B",16)
    pdf.cell(0,10,"Ecole Nationale des Sciences Appliquees",ln=True,align="C")
    pdf.ln(10)
    pdf.set_font("Arial","",14)
    pdf.cell(0,10,"Projet : Prediction des ventes",ln=True,align="C")
    pdf.ln(10)
    pdf.cell(0,10,f"Etudiant : {user_name}",ln=True,align="C")
    pdf.cell(0,10,f"Date : {datetime.now().strftime('%d/%m/%Y')}",ln=True,align="C")

    pdf.add_page()
    pdf.set_font("Arial","B",14)
    pdf.cell(0,10,"1. Historique des ventes",ln=True)
    pdf.image(img_path, x=10, w=180)

    pdf.add_page()
    pdf.cell(0,10,"2. Resultats de prediction",ln=True)
    pdf.set_font("Arial","",12)
    for i, v in enumerate(predictions, 1):
        pdf.cell(0,8,f"Jour {i} : {v:.2f}",ln=True)

    pdf_path = f"rapports/rapport_{user_name}.pdf"
    pdf.output(pdf_path)
    return pdf_path
