from reportlab.lib.pagesizes import A4
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image,
    Table, TableStyle, PageBreak
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.lib import colors
from datetime import datetime
import os

def generate_pdf_report(user, history_df, forecasts, metrics, plots, best_model, output_pdf):
    os.makedirs(os.path.dirname(output_pdf), exist_ok=True)

    doc = SimpleDocTemplate(
        output_pdf,
        pagesize=A4,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )

    styles = getSampleStyleSheet()
    
    # Styles Professionnels
    styles.add(ParagraphStyle(name="MainTitle", fontSize=24, leading=28, textColor=colors.HexColor("#2c3e50"), spaceAfter=20))
    styles.add(ParagraphStyle(name="SubTitle", fontSize=14, textColor=colors.HexColor("#7f8c8d"), spaceAfter=30))
    styles.add(ParagraphStyle(name="SectionTitle", fontSize=16, textColor=colors.HexColor("#2980b9"), spaceBefore=20, spaceAfter=10, borderPadding=5))
    styles.add(ParagraphStyle(name="NormalJustified", parent=styles['Normal'], alignment=TA_JUSTIFY, leading=14, fontSize=11))
    styles.add(ParagraphStyle(name="MetricValue", fontSize=18, textColor=colors.HexColor("#27ae60"), alignment=TA_CENTER))

    elements = []

    # --- Header ---
    company_name = user.get('company', 'AK_Forecast Enterprise')
    date_str = datetime.now().strftime("%d %B %Y")
    
    elements.append(Paragraph(f"RAPPORT DE PRÉVISION DES VENTES", styles["MainTitle"]))
    elements.append(Paragraph(f"Généré pour : <b>{company_name}</b> | Date : {date_str}", styles["SubTitle"]))
    elements.append(Paragraph("<hr/>", styles["Normal"]))
    elements.append(Spacer(1, 20))

    # --- 1. Executive Summary ---
    elements.append(Paragraph("1. Synthèse Exécutive", styles["SectionTitle"]))
    summary_text = (
        f"Ce rapport présente les prévisions de ventes générées par l'intelligence artificielle AK_Forecast. "
        f"L'analyse a identifié le modèle <b>{best_model}</b> comme étant le plus performant pour vos données. "
        f"Les prévisions couvrent une période de {len(forecasts[best_model])} jours à partir d'aujourd'hui."
    )
    elements.append(Paragraph(summary_text, styles["NormalJustified"]))
    elements.append(Spacer(1, 15))

    # --- Metrics Grid ---
    mae = metrics[best_model]['MAE']
    rmse = metrics[best_model]['RMSE']
    
    data_metrics = [
        ["Modèle Retenu", "Précision (MAE)", "Erreur (RMSE)", "Tendance Globale"],
        [best_model, f"{mae:.2f}", f"{rmse:.2f}", "Stable/Croissante"] # Tendance simplifiée
    ]
    
    t_metrics = Table(data_metrics, colWidths=[120, 100, 100, 120])
    t_metrics.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#ecf0f1")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor("#bdc3c7")),
    ]))
    elements.append(t_metrics)
    elements.append(Spacer(1, 25))

    # --- 2. Visualisation des Prévisions ---
    elements.append(Paragraph("2. Visualisation Stratégique", styles["SectionTitle"]))
    elements.append(Paragraph(
        "Le graphique ci-dessous illustre l'historique récent de vos ventes comparé aux prévisions futures générées.",
        styles["NormalJustified"]
    ))
    elements.append(Spacer(1, 10))

    if best_model in plots:
        img = Image(plots[best_model], width=480, height=260)
        elements.append(img)

    elements.append(Spacer(1, 20))

    # --- 3. Analyse Détaillée (Comparatif) ---
    elements.append(Paragraph("3. Comparatif Technique des Modèles", styles["SectionTitle"]))
    
    comp_data = [["Modèle", "MAE (Erreur Absolue)", "RMSE (Erreur Quadratique)"]]
    for m_name, m_vals in metrics.items():
        comp_data.append([m_name, f"{m_vals['MAE']:.4f}", f"{m_vals['RMSE']:.4f}"])

    t_comp = Table(comp_data, colWidths=[150, 150, 150])
    t_comp.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#34495e")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.whitesmoke, colors.HexColor("#ecf0f1")]),
    ]))
    elements.append(t_comp)

    # --- Footer ---
    elements.append(Spacer(1, 40))
    elements.append(Paragraph("<hr/>", styles["Normal"]))
    elements.append(Paragraph(
        "Généré automatiquement par AK_Forecast © 2026. "
        "Ce document est confidentiel et destiné à l'usage interne de l'entreprise.",
        ParagraphStyle(name="Footer", fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
    ))

    doc.build(elements)