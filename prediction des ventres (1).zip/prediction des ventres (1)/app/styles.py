import streamlit as st

def load_css():
    st.markdown("""
    <style>
    /* 1. IMPORT DE LA POLICE 'PLUS JAKARTA SANS' (Style Startup Moderne) */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', sans-serif;
        color: #1e293b; /* Gris Anthracite */
    }

    /* 2. FOND D'ÉCRAN SUBTIL (Pas juste blanc) */
    .stApp {
        background-color: #f8fafc;
        background-image: radial-gradient(#e2e8f0 1px, transparent 1px);
        background-size: 20px 20px;
    }

    /* 3. CARD DESIGN (Pour le login et les KPI) */
    div[data-testid="stVerticalBlock"] > div > div[data-testid="stVerticalBlock"] {
        background-color: white;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.08); /* Ombre douce et large */
        border: 1px solid #f1f5f9;
    }
    
    /* Exception pour ne pas encadrer toute la page, juste les blocs internes */
    .stApp > header {
        background-color: transparent !important;
    }

    /* 4. TYPOGRAPHIE */
    h1 {
        color: #0f172a !important;
        font-weight: 800 !important;
        letter-spacing: -1px;
        font-size: 3rem !important;
    }
    h3 {
        color: #64748b !important;
        font-weight: 500 !important;
    }

    /* 5. CHAMPS DE SAISIE (INPUTS) */
    .stTextInput > div > div > input {
        background-color: #f8fafc !important;
        color: #0f172a !important;
        border: 2px solid #e2e8f0 !important;
        border-radius: 12px !important;
        padding: 12px 15px !important;
        font-size: 1rem !important;
        transition: all 0.2s;
    }
    .stTextInput > div > div > input:focus {
        border-color: #3b82f6 !important; /* Bleu focus */
        background-color: #ffffff !important;
        box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1) !important;
    }

    /* 6. BOUTONS (Gradient & Arrondi) */
    .stButton > button {
        width: 100%;
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%) !important;
        color: white !important;
        border: none;
        border-radius: 12px !important;
        padding: 14px !important;
        font-weight: 600 !important;
        font-size: 1rem !important;
        box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);
        transition: transform 0.2s;
    }
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.3);
    }

    /* 7. ONGLETS (TABS) */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: #f1f5f9;
        padding: 5px;
        border-radius: 12px;
        display: inline-flex;
    }
    .stTabs [data-baseweb="tab"] {
        height: 40px;
        border-radius: 8px;
        border: none;
        background-color: transparent;
        color: #64748b;
        font-weight: 600;
    }
    .stTabs [aria-selected="true"] {
        background-color: #ffffff;
        color: #0f172a;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    </style>
    """, unsafe_allow_html=True)