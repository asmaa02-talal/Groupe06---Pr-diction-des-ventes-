# utils.py
import numpy as np
from PIL import Image
import tensorflow as tf

def load_and_preprocess_mnist():
    """
    Charge et prépare les données MNIST.
    Normalise les pixels entre 0 et 1, et ajoute une dimension de canal.
    Retourne (x_train, y_train), (x_test, y_test)
    """
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
    
    # Normalisation des pixels (0-255 → 0.0-1.0)
    x_train = x_train.astype('float32') / 255.0
    x_test = x_test.astype('float32') / 255.0
    
    # Ajout de la dimension du canal (gris → 1 canal) : (28,28) → (28,28,1)
    x_train = x_train[..., tf.newaxis]
    x_test = x_test[..., tf.newaxis]
    
    return (x_train, y_train), (x_test, y_test)

def predict_digit(model, image_path):
    """
    Prédire un chiffre à partir d'une image PNG/JPG.
    L'image doit être :
      - 28x28 pixels,
      - en niveaux de gris,
      - chiffre NOIR sur fond BLANC (comme MNIST).
    """
    # Charger et convertir en niveaux de gris
    img = Image.open(image_path).convert('L')
    # Redimensionner à 28x28 si nécessaire
    img = img.resize((28, 28))
    # Convertir en tableau numpy
    img_array = np.array(img)
    # Inverser les couleurs si fond noir (MNIST = fond blanc, chiffre noir)
    img_array = 255 - img_array
    # Normaliser
    img_array = img_array.astype('float32') / 255.0
    # Ajouter dimensions batch et canal : (28,28) → (1,28,28,1)
    img_array = img_array.reshape(1, 28, 28, 1)

    # Prédiction
    prediction = model.predict(img_array)
    predicted_digit = np.argmax(prediction)
    confidence = np.max(prediction)
    return predicted_digit, confidence