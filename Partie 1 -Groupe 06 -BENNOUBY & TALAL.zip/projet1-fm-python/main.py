# main.py
import numpy as np
import tensorflow as tf
from model import create_cnn_model
from utils import load_and_preprocess_mnist, predict_digit

def main():
    print("Chargement des données MNIST...")
    (x_train, y_train), (x_test, y_test) = load_and_preprocess_mnist()

    print("Création du modèle CNN...")
    model = create_cnn_model()

    print("Entraînement du modèle...")
    history = model.fit(x_train, y_train, epochs=5, batch_size=32,
                        validation_data=(x_test, y_test), verbose=1)

    print("Évaluation finale...")
    test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nPrécision sur le jeu de test : {test_acc:.4f}")

    # Afficher les courbes d'apprentissage
    # plot_training_history(history)

    # Sauvegarder le modèle
    model.save("mnist_cnn_model.h5")
    print("Modèle sauvegardé sous 'mnist_cnn_model.h5'")

    #Exemple de prédiction sur une image personnalisée (décommente si tu as une image)
    digit, conf = predict_digit(model, "test_image.png")
    print(f"Chiffre prédit : {digit} (confiance : {conf:.2%})")

if __name__ == "__main__":
    main()