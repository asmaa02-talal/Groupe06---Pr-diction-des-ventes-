# gui.py
import tkinter as tk
from tkinter import Canvas, Button, Label
from PIL import Image, ImageDraw, ImageOps
import numpy as np
import tensorflow as tf

# Charger le modèle sauvegardé (généré par main.py)
try:
    model = tf.keras.models.load_model('mnist_cnn_model.h5')
except Exception as e:
    print("Erreur : Impossible de charger le modèle 'mnist_cnn_model.h5'")
    print("Assure-toi d'avoir exécuté 'main.py' au moins une fois.")
    exit()

class DigitDrawer:
    def __init__(self, root):
        self.root = root
        self.root.title("Reconnaissance de chiffres manuscrits")
        self.root.geometry("400x550")
        self.root.resizable(False, False)

        # Titre
        title_label = Label(root, text="Dessinez un chiffre (0-9)", font=("Arial", 14))
        title_label.pack(pady=10)

        # Canevas de dessin (280x280 pixels)
        self.canvas = Canvas(root, width=280, height=280, bg='white', cursor="pencil")
        self.canvas.pack(pady=10)

        # Zone de résultat
        self.result_label = Label(root, text="", font=("Arial", 16), fg="blue")
        self.result_label.pack(pady=10)

        # Boutons
        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)

        self.predict_button = Button(button_frame, text="Prédire", command=self.predict_digit, width=12)
        self.predict_button.grid(row=0, column=0, padx=5)

        self.clear_button = Button(button_frame, text="Effacer", command=self.clear_canvas, width=12)
        self.clear_button.grid(row=0, column=1, padx=5)

        # Initialiser l'image PIL (280x280, niveaux de gris, fond blanc)
        self.image = Image.new('L', (280, 280), 'white')
        self.draw = ImageDraw.Draw(self.image)

        # Lier les événements souris
        self.canvas.bind("<B1-Motion>", self.paint)
        self.canvas.bind("<Button-1>", self.paint)

    def paint(self, event):
        """Dessiner un cercle noir sur le canevas et dans l'image PIL."""
        x, y = event.x, event.y
        r = 8  # Rayon du pinceau (plus gros = plus facile à dessiner)
        self.canvas.create_oval(x - r, y - r, x + r, y + r, fill='black', outline='black')
        self.draw.ellipse([x - r, y - r, x + r, y + r], fill='black')

    def clear_canvas(self):
        """Effacer le canevas et réinitialiser l'image."""
        self.canvas.delete("all")
        self.result_label.config(text="")
        self.image = Image.new('L', (280, 280), 'white')
        self.draw = ImageDraw.Draw(self.image)

    def predict_digit(self):
        """Prédire le chiffre dessiné."""
        # Redimensionner à 28x28
        img_resized = self.image.resize((28, 28), Image.LANCZOS)
        
        # Inverser les couleurs : MNIST = chiffre noir sur fond blanc → ici on a dessiné noir sur blanc,
        # mais PIL stocke blanc=255, noir=0 → on inverse pour correspondre à MNIST.
        img_inverted = ImageOps.invert(img_resized)
        
        # Convertir en tableau numpy
        img_array = np.array(img_inverted)
        img_array = img_array.astype('float32') / 255.0
        img_array = img_array.reshape(1, 28, 28, 1)

        # Prédiction
        prediction = model.predict(img_array, verbose=0)
        predicted_digit = np.argmax(prediction)
        confidence = np.max(prediction)

        # Afficher le résultat
        self.result_label.config(
            text=f"Chiffre prédit : {predicted_digit}\nConfiance : {confidence:.2%}"
        )

# Lancer l'application
if __name__ == "__main__":
    root = tk.Tk()
    app = DigitDrawer(root)
    root.mainloop()